import React from 'react';

const Product = (props) => {
    return (
        <div>
            <p>Nombre: {props.nombre}</p>
            <p>Descripcion: {props.descripcion}</p>
            <p>Precio: {props.precio}</p>
            <p>SKU: {props.sku}</p>
            <p>Stock: {props.stock}</p>
        </div>

    );
}

export default Product;
