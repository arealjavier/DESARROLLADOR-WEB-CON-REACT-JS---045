import './App.css'
import Product from './components/Product/Product'

function App() {
 
  return (
    <>
      <Product nombre="NUX MG30" descripcion="Ejemplo Descripcion" sku="AA872AL" precio="$ 375000" stock="30"></Product>
    </>
  )
}

export default App
